let code = {};

code.import = `
"usingComponents": {
    "i-icon": "../../dist/icon/index"
}
`;
code.usage = `
<i-icon type="activity" size="28" color="#80848f" />
`;

export default code;