let code = {};

code.import = `
"usingComponents": {
    "i-panel": "../../dist/panel/index"
}
`;
code.usage = `
<i-panel title="标题">
    <view style="padding: 15px;">PANEL 内容区域</view>
</i-panel>
`;

export default code;